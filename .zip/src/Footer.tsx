import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

const Footer = () => {
  const [data, setData] = useState<any>([]);
  const GetserverUrl = 'https://eventservers.onrender.com/api/getData';
  const organizeData = (rawData: any) => {
    const parents = rawData.filter((item: any) => !item.ParentId);
    return parents.map((parent: any) => ({
      ...parent,
      children: rawData.filter((child: any) => child.ParentId === parent.id)
    }));
  };
  const getPublicServerData = async (tableName: any) => {
    let results: any = [];
    try {
      var myHeaders = new Headers();
      myHeaders.append("Content-Type", "application/json");

      var raw = JSON.stringify({
        "table": `${tableName}`
      });

      var requestOptions: any = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow'
      };

      fetch("https://gruene-weltweit.de/SPPublicAPIs/getDataAll.php", requestOptions)
        .then(response => response.text())
        .then((result: any) => {
          result = JSON.parse(result)
          results = result?.data
          const footerItems = organizeData(results);
          setData(footerItems);
        })
        .catch(error => console.log('error', error));
    } catch (error) {
      console.error('An error occurred:', error);
    }
    return results;
  }
  useEffect(() => {
    const footerData = async () => {
      const tableName = "Footer";
      try {
        const response: any = await getPublicServerData(`${tableName}`)

      } catch (error) {
        console.error('An error occurred:', error);
      }
    };
    footerData();
  }, []);



  return (
    <div>
      <footer className="bg-sitecolor">
        <section className="footer-widgets-wrap">
          <Container>
            <Row>
              {data
                .slice() // Create a copy of the array to avoid mutating the original data
                .sort((a: any, b: any) => a.SortOrder - b.SortOrder) // Sort the array based on SortOrder of parent
                .map((parent: any) => (
                  <Col key={parent.id}>
                    <h4>{parent.Title}</h4>
                    <ul className="list-unstyled">
                      {parent.children
                        .slice() // Create a copy of the children array to avoid mutating the original data
                        .sort((a: any, b: any) => a.SortOrder - b.SortOrder) // Sort the array based on SortOrder of children
                        .map((child: any) => (
                          <li key={child.id} className="widget_links">
                            {child.Title === "Impressum" ? (
                              <Link to={child.Title}>
                                {child.Title}
                              </Link>
                            ) : child.Title === "Pressekontakt" ? (
                              <Link
                                to="/OV-in-den-Medien"

                              >
                                {child.Title}
                              </Link>
                            ) : (
                              <Link to={child.href} rel="noopener noreferrer">
                                {child.Title}
                              </Link>
                            )}
                          </li>
                        ))}
                    </ul>
                  </Col>
                ))}
            </Row>
          </Container>
        </section>
        <section className="copyrights p-2">
          <Container>
            <Row>
              <div className="col-12 mb-4 mt-4">
                <hr></hr>
              </div>
            </Row>
            <Row>
              <Col md="10" xs="12" >
                <p><span className='me-1'> Powered By : </span> <a href="https://hochhuth-consulting.de/"> Hochhuth Consulting GmbH </a></p>
                {/* <a className="gap4 ms-2 px-4 valign-middle footerSignIn-Link" 
                href='https://grueneweltweit.sharepoint.com/sites/GrueneWeltweit/Washington/Public/SitePages/HomeGruene.aspx'>
                  <span className="svg__iconbox svg__icon--signin light">
                    </span>
                    <span className='footerSignIn-LinkText'>Sign In</span>
                    </a> */}
              </Col>
              {/* <Col md="2" xs="4">
                <a href="https://www.gruene-weltweit.de"><img
                  src="https://gruene-weltweit.de/SiteAssets/logo2.png"
                  alt="Gruene Logo" className="footer-logo"></img></a>
              </Col> */}
            </Row>
          </Container>
        </section>
      </footer>
    </div>
  );
};

export default Footer;
